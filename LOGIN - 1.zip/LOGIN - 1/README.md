# [Read full article here](https://thedevsaddam.github.io/post/lets-make-a-simple-todo-app-with-go/)
